package com.example;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

class ReadJSON {
	
	public static void main(String[] args) throws IOException{
		
		BufferedReader br = new BufferedReader(new FileReader("Products.json"));
		
		String line;
		
		while((line = br.readLine()) != null) {
			
			System.out.println(line);
			
		}
		
		br.close();
		
	}
	
}