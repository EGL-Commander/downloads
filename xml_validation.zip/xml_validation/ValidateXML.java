package com.example;

import javax.xml.XMLConstants;
import javax.xml.validation.*;
import javax.xml.transform.stream.StreamSource;
import java.io.File;

public class ValidateXML {
	
	public static void main(String[] args) throws Exception {
		
		SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		
		Schema schema = factory.newSchema(new File("Employee.xsd"));
		
		Validator validator = schema.newValidator();
		
		validator.validate(new StreamSource(new File("Employee.xml")));
		
		System.out.println("XML is valid");

	}

}