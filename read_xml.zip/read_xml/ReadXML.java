package com.example;

import java.io.File;
import javax.xml.parsers.*;
import org.w3c.dom.*;


public class ReadXML {

	public static void main(String[] args) throws Exception{
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		
		DocumentBuilder builder = factory.newDocumentBuilder();
		
		Document doc = builder.parse(new File("Student.xml"));
		
		doc.getDocumentElement().normalize();
		
		NodeList list = doc.getElementsByTagName("Student");
		
		for (int i = 0; i < list.getLength(); i++) {

			Element student = (Element) list.item(i);
			
			String id = student.getElementsByTagName("ID").item(0).getTextContent();
			String name = student.getElementsByTagName("Name").item(0).getTextContent();
			String dept = student.getElementsByTagName("Department").item(0).getTextContent();
			
			System.out.println( id + " " + name + " " + dept);

		}

	}

}
